<html>

<head>
<?php include('./include/dbcon.php');?>
<?php include('./include/import.php');?>
</head>

<body>

<?php include('./include/header.php');?>

<p>As this site is under construction, please do not store any personal information as security is not guaranteed.</p>

</body>
</html>
