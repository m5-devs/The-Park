<footer class="page-footer teal" style="margin-top: 0;">
	<div class="container">
		<div class="row">
			<div class="col l6 s12">
				<h5>The Park</h5>
				<p class="text-lighten-4">Created by <a href="mailto:alexwohlbruck@gmail.com" class="grey-text text-lighten-4">Alex Wohlbruck</a> and <a href="mailto:kasimirkhschulz@gmail.com" class="grey-text text-lighten-4">Kasimir Schulz</a></p>
			</div>
			<div class="col l3 s12">
				<!-- <h5>Settings</h5>
				<ul>
					<li><a href="#!">Link 1</a></li>
					<li><a href="#!">Link 2</a></li>
					<li><a href="#!">Link 3</a></li>
					<li><a href="#!">Link 4</a></li>
				</ul> -->
			</div>
			<div class="col l3 s12">
				<!-- <h5>Connect</h5>
				<ul>
					<li><a href="#!">Link 1</a></li>
					<li><a href="#!">Link 2</a></li>
					<li><a href="#!">Link 3</a></li>
					<li><a href="#!">Link 4</a></li>
				</ul> -->
			</div>
		</div>
	</div>
	<div class="footer-copyright">
		<div class="container">
		<span>&copy; <?php echo date('Y') - 297; ?> &nbsp;|&nbsp; Illuminati #hackedbyanonymous</span>
		</div>
	</div>
</footer>
