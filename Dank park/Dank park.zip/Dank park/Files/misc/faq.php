<?php
include ("inc/header.inc.php");
?>
<div style="margin: 1px;">
	<h1>FAQ</h1>
<ol>
	<li id="profilepicFAQ"><b>How do I change my profile picture?</b><br />Insert the image’s url (or web address) into the box that says image URL.</li>
	<li><b>How do I find an image’s url?</b><br />Go to your image and right click, there will be an option that says “Copy Image URL” select that and paste into the Image URL box.</li>
	<li><b>Can I use gifs?</b><br />Yes. To insert any image or gif write this text: < img src = “ image URL ”/>.</li>
</ol>
</div>
</body>
