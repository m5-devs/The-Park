<?php require_once('../include/dbcon.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
	<?php require_once('../include/import.php');?>

	<style>
		/* CSS */
	</style>
</head>
	
<body class="spaced">
	<?php require_once('../include/header.php');?>

	<div class="container">
		<!-- HTML -->
	</div>

	<script>
		//Javascript
	</script>
</body>
</html>