<html>
  <head>
    
  </head>
  <body style="background-color: red;">

<div style="width: 50px; height: 50px;">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- ad 1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2269091303898266"
     data-ad-slot="8020218232"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
  
  
</div>
  </body> 
</html>